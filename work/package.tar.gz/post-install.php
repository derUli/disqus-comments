<?php
Settings::register("disqus_id", "[insert-your-disqus-shortname-here]")
