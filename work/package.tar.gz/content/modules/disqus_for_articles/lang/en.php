<?php
define ( "TRANSLATION_DISQUS_FOR_ARTICLES", "Disqus for Articles" );
define ( "TRANSLATION_DISQUS_ID", "Disqus ID:" );
