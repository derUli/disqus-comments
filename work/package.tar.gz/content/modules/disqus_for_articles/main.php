<?php
function disqus_for_articles_render() {
	return "";
}
?>
