<?php
define ( "TRANSLATION_DISQUS_FOR_ARTICLES", "Disqus für Artikel" );
define ( "TRANSLATION_DISQUS_ID", "Disqus ID:" );
